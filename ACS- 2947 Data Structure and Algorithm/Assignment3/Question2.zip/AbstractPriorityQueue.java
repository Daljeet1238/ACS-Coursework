import java.util.Comparator;

public abstract class AbstractPriorityQueue<K,V> implements PriorityQueue<K,V>{
    
    //-------------------------- nested PQEntry class -------------------------
    protected static class PQEntry<K,V> implements Entry<K,V>{
        private K k;
        private V v;

        public PQEntry(K key, V value){
            k = key;
            v = value;
        }

        // getters
        public K getKey(){
            return k;
        }

        public V getValue(){
            return v;
        }

        //setters
        protected void setKey(K key){
            k = key;
        }

        protected void setValue(V value){
            v = value;
        }

        @Override
        public String toString(){
            return "(" + k + ", " + v + ")";
        }
    }
    //--------------------- end of nested PQEntry class ------------------

    private Comparator<K> comp;

    protected AbstractPriorityQueue(Comparator<K> c){
        comp = c;
    }

    protected AbstractPriorityQueue(){
        this(new DefaultComparator<K> ());
    }

    protected int compare(Entry<K,V> a, Entry<K, V> b){
        return comp.compare(a.getKey(), b.getKey());
    }

    // determine whether a key is valid
    protected boolean checkKey(K key) throws IllegalArgumentException{
        try{
            return (comp.compare(key,key) == 0);
        }catch(ClassCastException e){
            throw new IllegalArgumentException("Incompatible key");
        }
    }

    public boolean isEmpty(){
        return size() == 0;
    }
}
