
// Save the URL
let color_url = FILL THIS IN;


function init() {
}

function processFormSubmit(event) {
}

function processXHR(xhr) {

}

function addColorToSelect(color_code, color_name) {
	
}

function createNewSwatchBox(color_code, color_name) {

}
